# zbx-block-user

Módulo para o **Zabbix 7.0 LTS** que adiciona um botão **"Bloquear"** na listagem de usuários (`Usuários > Usuários`), permitindo bloquear imediatamente contas locais sem o workaround de brute-force manual.

## Problema que resolve

Durante a transição de usuários locais para usuários provisionados via LDAP/JIT com Authentik, o time de governança precisa bloquear a conta local original após o provisionamento. O Zabbix não oferece um botão nativo de bloqueio — apenas desbloqueio. A solução manual de forçar logins incorretos é inaceitável em ambiente de segurança.

## Como funciona

O Zabbix bloqueia um usuário quando o campo `users.attempt_failed` atinge o valor configurado em `Administração > Autenticação > Tentativas de login`. O módulo simplesmente executa esse `UPDATE` diretamente, de forma controlada e auditável.

```sql
UPDATE users
SET attempt_failed = <max_attempts>,
    attempt_clock  = <unix_timestamp>,
    attempt_ip     = '127.0.0.1'
WHERE userid = <userid>
```

## Requisitos

- Zabbix 7.0 LTS (frontend PHP)
- PHP 8.x
- Permissão de Super Admin no Zabbix

## Instalação

```bash
chmod +x install.sh
sudo ./install.sh
```

Depois:
1. `Administração > Geral > Módulos`
2. Clique em **"Verificar módulos ausentes"**
3. Habilite **"Block Local User"**

## Uso

1. Acesse `Usuários > Usuários`
2. Marque o(s) checkbox(es) dos usuários a bloquear
3. Clique no botão **"Bloquear"** (aparece ao lado do "Desbloquear")
4. Confirme no diálogo

> **Proteções:**
> - Não é possível bloquear o próprio usuário logado
> - Usuários já bloqueados são ignorados com aviso
> - Apenas Super Admins podem executar a ação

## Reverter

Use o botão nativo **"Desbloquear"** do Zabbix para reverter.

## Estrutura

```
zbx-block-user/
├── manifest.json                          # Declaração do módulo
├── Module.php                             # Classe principal — injeta o JS via onBeforeAction
├── install.sh                             # Script de instalação
├── actions/
│   └── CControllerBlockUserBlock.php      # Controller da action blockuser.block
├── assets/
│   └── js/
│       └── block_user.js                  # Lógica do botão (injeção DOM + AJAX)
└── views/
    └── blockuser.inject.php               # View auxiliar (não usada diretamente)
```

## Autor

Rafael Leão — [@leaoereno](https://github.com/leaoereno)
